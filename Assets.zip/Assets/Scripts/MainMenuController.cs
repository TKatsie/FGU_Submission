using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenuController : MonoBehaviour
{
    [Header("Cài Đặt")]
    [Tooltip("Tên Scene chứa màn chơi chính (phải khớp CHÍNH XÁC tên Scene trong Build Settings).")]
    public string gameSceneName = "Level";

    [Tooltip("Tên Scene chứa màn Tutorial (phải khớp CHÍNH XÁC tên Scene trong Build Settings).")]
    public string tutorialSceneName = "Storage";

    // ── Gắn hàm này vào nút "Chơi" (Play) qua Button > OnClick() ────────────
    public void OnPlayButton()
    {
        Debug.Log("Bắt đầu game - đang tải Scene: " + gameSceneName);

        // Đảm bảo Time.timeScale trở về bình thường trước khi vào game,
        // phòng trường hợp trước đó có gì đó để timeScale = 0 (ví dụ pause).
        Time.timeScale = 1f;

        SceneManager.LoadScene(gameSceneName);
    }

    // ── Gắn hàm này vào nút "Tutorial" qua Button > OnClick() ───────────────
    public void OnTutorialButton()
    {
        Debug.Log("Mở màn Tutorial - đang tải Scene: " + tutorialSceneName);

        Time.timeScale = 1f;

        SceneManager.LoadScene(tutorialSceneName);
    }

    // ── Gắn hàm này vào nút "Thoát" (Quit) qua Button > OnClick() ───────────
    public void OnQuitButton()
    {
        Debug.Log("Thoát game.");

#if UNITY_EDITOR
        // Trong Unity Editor, Application.Quit() không hoạt động,
        // nên dừng Play mode thay thế để test dễ dàng.
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }

    // ── Tùy chọn: gắn vào nút "Cài Đặt" nếu bạn có màn hình Settings riêng ──
    public void OnSettingsButton()
    {
        Debug.Log("Mở màn hình Cài Đặt (chưa triển khai - tự thêm sau).");
        // Ví dụ: settingsPanel.SetActive(true);
    }
}
