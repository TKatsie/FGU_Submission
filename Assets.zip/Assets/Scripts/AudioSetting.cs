using UnityEngine;
using UnityEngine.UI;

public class AudioSetting : MonoBehaviour
{
    [Header("References")]
    [Tooltip("Kéo Panel chứa thanh trượt âm lượng vào đây (nên để TẮT sẵn trong Hierarchy).")]
    public GameObject audioPanel;

    [Tooltip("Kéo UI Slider dùng để tăng giảm âm lượng vào đây.")]
    public Slider volumeSlider;

    [Tooltip("Kéo Panel Pause Menu (Resume/Restart/Audio/Quit) vào đây - sẽ tự ẩn khi mở Audio Panel, tự hiện lại khi đóng.")]
    public GameObject pauseMenuPanel;

    [Header("Cài Đặt")]
    [Tooltip("Tên key dùng để lưu âm lượng vào PlayerPrefs, giữ nguyên nếu không có lý do đổi.")]
    public string playerPrefsKey = "GameVolume";

    private void Start()
    {
        // Đọc lại âm lượng đã lưu từ lần chơi trước (mặc định = 1 = 100% nếu chưa từng lưu)
        float savedVolume = PlayerPrefs.GetFloat(playerPrefsKey, 1f);
        AudioListener.volume = savedVolume;

        if (volumeSlider != null)
        {
            volumeSlider.value = savedVolume;
            volumeSlider.onValueChanged.AddListener(OnVolumeChanged);
        }

        if (audioPanel != null)
        {
            audioPanel.SetActive(false); // ẩn Panel lúc bắt đầu
        }
    }

    // ── Gắn hàm này vào nút "Audio" qua Button > OnClick() ──────────────────
    public void OnAudioButton()
    {
        if (audioPanel != null)
        {
            bool isOpening = !audioPanel.activeSelf;
            audioPanel.SetActive(isOpening);

            // Ẩn Pause Menu khi mở Audio Panel, hiện lại khi đóng
            if (pauseMenuPanel != null)
            {
                pauseMenuPanel.SetActive(!isOpening);
            }
        }
    }

    // ── Gắn hàm này vào nút "Đóng" (nếu có) trong Panel Audio ────────────────
    public void OnCloseAudioPanel()
    {
        if (audioPanel != null)
        {
            audioPanel.SetActive(false);
        }

        // Hiện lại Pause Menu khi đóng Audio Panel
        if (pauseMenuPanel != null)
        {
            pauseMenuPanel.SetActive(true);
        }
    }

    // ── Tự động gọi mỗi khi kéo thanh trượt ──────────────────────────────────
    private void OnVolumeChanged(float newValue)
    {
        AudioListener.volume = newValue;
        PlayerPrefs.SetFloat(playerPrefsKey, newValue);
        PlayerPrefs.Save();
    }
}
