using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class LevelController : MonoBehaviour
{
    [Header("References")]
    [Tooltip("Kéo Panel End Menu vào đây (nên để TẮT sẵn trong Hierarchy).")]
    public GameObject endMenuPanel;

    [Tooltip("Text tiêu đề lớn (chữ 'End' trong Square) - script sẽ đổi thành FINISHED hoặc YOU'RE DEAD tùy trường hợp.")]
    public TextMeshProUGUI titleText;

    [Tooltip("Text hiển thị thời gian vừa chơi xong, ví dụ '01:23.45'.")]
    public TextMeshProUGUI timeText;

    [Tooltip("Text hiển thị kỷ lục nhanh nhất từ trước tới giờ.")]
    public TextMeshProUGUI bestTimeText;

    [Tooltip("Text hiện dòng 'NEW RECORD!' - nên để sẵn TẮT (inactive) trong Hierarchy, script sẽ tự bật khi cần.")]
    public GameObject newRecordText;

    [Header("Cài Đặt")]
    [Tooltip("Tên Scene Main Menu, dùng cho nút quay về Menu.")]
    public string mainMenuSceneName = "MainMenu";

    // ── Private State ─────────────────────────────────────────────────────────

    private float elapsedTime = 0f;
    private bool isTiming = true;
    private bool levelCompleted = false;

    // Key lưu kỷ lục riêng cho từng Scene, để mỗi màn có kỷ lục độc lập
    private string BestTimeKey => "BestTime_" + SceneManager.GetActiveScene().name;

    // ── Unity Messages ────────────────────────────────────────────────────────

    private void Awake()
    {
        elapsedTime = 0f;
        isTiming = true;
        levelCompleted = false;

        if (endMenuPanel != null)
        {
            endMenuPanel.SetActive(false);
        }

        if (newRecordText != null)
        {
            newRecordText.SetActive(false);
        }
    }

    private void Update()
    {
        if (isTiming)
        {
            // Dùng Time.deltaTime bình thường - nếu game bị Pause (Time.timeScale = 0),
            // đồng hồ tự động dừng đếm theo, đúng như mong muốn khi tính thời gian chơi thực tế.
            elapsedTime += Time.deltaTime;
        }
    }

    // ── Gọi hàm này từ trigger/checkpoint cuối màn khi người chơi hoàn thành ──
    public void CompleteLevel()
    {
        if (levelCompleted) return; // tránh gọi trùng nhiều lần
        levelCompleted = true;
        isTiming = false;

        Debug.Log("Level complete! Time: " + FormatTime(elapsedTime));

        ShowEndMenu();
    }

    // ── Hiển thị End Menu, xử lý so sánh kỷ lục ─────────────────────────────

    private void ShowEndMenu()
    {
        if (endMenuPanel != null)
        {
            endMenuPanel.SetActive(true);
        }

        if (titleText != null)
        {
            titleText.text = "FINISHED";
        }

        if (timeText != null)
        {
            timeText.text = FormatTime(elapsedTime);
        }

        // Đọc kỷ lục cũ đã lưu (mặc định = số rất lớn nếu chưa từng có kỷ lục)
        float bestTime = PlayerPrefs.GetFloat(BestTimeKey, float.MaxValue);
        bool isNewRecord = elapsedTime < bestTime;

        if (isNewRecord)
        {
            // Lưu kỷ lục mới
            PlayerPrefs.SetFloat(BestTimeKey, elapsedTime);
            PlayerPrefs.Save();

            bestTime = elapsedTime; // để hiển thị đúng luôn kỷ lục vừa đạt được

            if (newRecordText != null)
            {
                newRecordText.SetActive(true);
            }

            Debug.Log("New record!");
        }
        else
        {
            if (newRecordText != null)
            {
                newRecordText.SetActive(false);
            }
        }

        if (bestTimeText != null)
        {
            bestTimeText.text = "Best Time: " + FormatTime(bestTime);
        }
    }

    // ── Gọi hàm này từ PlayerHealth khi nhân vật chết ────────────────────────
    public void ShowDeathScreen()
    {
        if (levelCompleted) return; // đã hoàn thành màn rồi thì không hiện màn chết đè lên
        levelCompleted = true; // khóa lại, tránh gọi trùng
        isTiming = false;

        if (endMenuPanel != null)
        {
            endMenuPanel.SetActive(true);
        }

        if (titleText != null)
        {
            titleText.text = "YOU'RE DEAD";
        }

        // Khi chết thì không cần hiện thời gian/kỷ lục, ẩn hết cho gọn
        if (timeText != null)
        {
            timeText.text = "";
        }

        if (bestTimeText != null)
        {
            bestTimeText.text = "";
        }

        if (newRecordText != null)
        {
            newRecordText.SetActive(false);
        }

        Debug.Log("Player died - showing YOU'RE DEAD screen.");
    }

    // ── Định dạng giây thành "mm:ss.ff" cho dễ đọc ───────────────────────────

    private string FormatTime(float timeInSeconds)
    {
        int minutes = Mathf.FloorToInt(timeInSeconds / 60f);
        int seconds = Mathf.FloorToInt(timeInSeconds % 60f);
        int hundredths = Mathf.FloorToInt((timeInSeconds * 100f) % 100f);

        return string.Format("{0:00}:{1:00}.{2:00}", minutes, seconds, hundredths);
    }

    // ── Gắn vào nút "Chơi Lại" trong End Menu qua Button > OnClick() ────────
    public void OnRestartButton()
    {
        Time.timeScale = 1f;
        Scene currentScene = SceneManager.GetActiveScene();
        SceneManager.LoadScene(currentScene.name);
    }

    // ── Gắn vào nút "Về Menu" trong End Menu qua Button > OnClick() ─────────
    public void OnMainMenuButton()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(mainMenuSceneName);
    }

    // ── Public Getter (nếu cần dùng nơi khác, ví dụ UI hiện thời gian đang chạy) ─
    public float ElapsedTime => elapsedTime;
}
