using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;

public class PauseMenuController : MonoBehaviour
{
    [Header("References")]
    [Tooltip("Kéo Panel UI chứa menu Pause vào đây (mặc định nên để TẮT sẵn trong Hierarchy).")]
    public GameObject pausePanel;

    [Header("Cài Đặt")]
    [Tooltip("Tên Scene của Menu chính, dùng cho nút 'Về Menu'.")]
    public string mainMenuSceneName = "MainMenu";

    // ── Private State ─────────────────────────────────────────────────────────

    private InputAction pauseAction;
    private bool isPaused = false;

    // ── Unity Messages ────────────────────────────────────────────────────────

    private void Awake()
    {
        pauseAction = new InputAction("Pause", binding: "<Keyboard>/escape");

        // Đảm bảo Panel tắt sẵn lúc bắt đầu game
        if (pausePanel != null)
        {
            pausePanel.SetActive(false);
        }
    }

    private void OnEnable()
    {
        pauseAction.Enable();
    }

    private void OnDisable()
    {
        pauseAction.Disable();
    }

    private void Update()
    {
        if (pauseAction.WasPressedThisFrame())
        {
            if (isPaused)
                Resume();
            else
                Pause();
        }
    }

    // ── Pause / Resume ───────────────────────────────────────────────────────

    public void Pause()
    {
        isPaused = true;
        Time.timeScale = 0f;

        if (pausePanel != null)
        {
            pausePanel.SetActive(true);
        }

        Debug.Log("Game đã Pause.");
    }

    public void Resume()
    {
        isPaused = false;
        Time.timeScale = 1f;

        if (pausePanel != null)
        {
            pausePanel.SetActive(false);
        }

        Debug.Log("Game đã tiếp tục.");
    }

    // ── Gắn vào nút "Tiếp Tục" (Resume) qua Button > OnClick() ──────────────
    public void OnResumeButton()
    {
        Resume();
    }

    // ── Gắn vào nút "Chơi Lại" (Restart) qua Button > OnClick() ─────────────
    public void OnRestartButton()
    {
        Time.timeScale = 1f;
        Debug.Log("Chơi lại màn hiện tại.");

        Scene currentScene = SceneManager.GetActiveScene();
        SceneManager.LoadScene(currentScene.name);
    }

    // ── Gắn vào nút "Về Menu" qua Button > OnClick() ─────────────────────────
    public void OnMainMenuButton()
    {
        Time.timeScale = 1f;
        Debug.Log("Quay về Menu chính.");

        SceneManager.LoadScene(mainMenuSceneName);
    }

    // ── Gắn vào nút "Thoát" qua Button > OnClick() ───────────────────────────
    public void OnQuitButton()
    {
        Debug.Log("Thoát game.");

#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }

    // ── Public Getter ─────────────────────────────────────────────────────────
    public bool IsPaused => isPaused;

    // ── An toàn: đảm bảo timeScale trả về bình thường khi object bị hủy ─────
    private void OnDestroy()
    {
        Time.timeScale = 1f;
    }
}
