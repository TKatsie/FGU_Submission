﻿using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(Rigidbody2D))]
[RequireComponent(typeof(BoxCollider2D))]
[RequireComponent(typeof(SpriteRenderer))]
[RequireComponent(typeof(Animator))]
public class RetroPlayerController : MonoBehaviour
{
    [Header("Movement Speeds")]
    public float walkSpeed = 8f;
    public float runSpeed = 13f;
    public float crouchSpeed = 4f;
    public float jumpForce = 16f;

    [Header("Jump Buffering (Grounded)")]
    [Tooltip("How early (in seconds) the player can press Jump before landing and still have it register.")]
    public float jumpBufferThreshold = 0.15f;
    private float jumpBufferCounter;

    [Header("Ledge & Platform Grab Coyote Time")]
    [Tooltip("How long (in seconds) the player's jump command stays active to register a grab if they fall near a ledge.")]
    public float grabCoyoteThreshold = 0.15f;
    private float grabCoyoteCounter;

    [Header("Roll Settings")]
    public float rollSpeed = 22f;
    public float rollDuration = 0.4f;
    public float rollEndStunDuration = 0.25f;
    public float rollHeightDecrement = 0.4f;
    private float rollTimeCounter;
    private float rollEndStunCounter;
    private bool isRollStunned = false;

    [Header("Dynamic Gravity Settings")]
    public float riseMultiplier = 1.8f;
    public float fallMultiplier = 2.5f;

    [Header("Hitbox Settings")]
    public float crouchHeightDecrement = 0.5f;

    [Header("Landing Settings")]
    public float landVelocityThreshold = -15f;
    public float stunDuration = 0.5f;
    private float stunTimeCounter = 0f;
    private bool isStunned = false;

    [Header("Hurt Settings")]
    private bool isKnockedBack = false;
    private float knockbackTimer = 0f;

    [Header("Ledge Detection & Climb")]
    public Vector2 ledgeGrabBoxSize = new Vector2(0.4f, 0.6f);
    public Vector2 ledgeGrabBoxOffset = new Vector2(0f, -0.3f);
    public float climbDuration = 0.35f;
    public Vector2 hangOffset = new Vector2(0.3f, -0.9f);
    public Vector2 landOffset = new Vector2(0.4f, 0.6f);
    public float leapBackSpeedX = 6f;
    public float leapBackSpeedY = 8f;

    [Header("Platform Hang & Climb")]
    [Tooltip("Detection box for grabbing walkthrough platforms. Should point UP towards the head.")]
    public Vector2 platformGrabBoxSize = new Vector2(0.6f, 0.4f);
    public Vector2 platformGrabBoxOffset = new Vector2(0f, 0.6f);

    [HideInInspector] public bool isAiming = false;

    [Tooltip("How long the pull-up animation takes (Controls the SPEED of the climb).")]
    public float platformClimbDuration = 0.25f;

    [Tooltip("Y = How far below the platform surface the player hangs. X = Keep 0 to stay exactly where you jumped.")]
    public Vector2 platformHangOffset = new Vector2(0f, -0.8f);

    [Tooltip("Y = How high above the platform surface the player lands (Controls the HEIGHT). X = Forward push after climbing (Keep 0 for straight up).")]
    public Vector2 platformLandOffset = new Vector2(0f, 0.1f);

    // ── Component References ──────────────────────────────────────────────────
    private Rigidbody2D rb;
    private BoxCollider2D col;
    private SpriteRenderer spriteRenderer;
    private Animator animator;


    // ── Audio Clips ──────────────────────────────────────────────────
    [SerializeField] private AudioClip jumpSoundClip;

    // ── Input Actions ─────────────────────────────────────────────────────────
    private InputAction moveAction;
    private InputAction jumpAction;
    private InputAction runAction;
    private InputAction crouchAction;
    private InputAction dropAction;
    private InputAction rollAction;

    // ── General State ─────────────────────────────────────────────────────────
    private Vector2 defaultColSize;
    private Vector2 defaultColOffset;
    private bool isCrouching = false;
    private bool isRolling = false;
    private bool combatLocked = false;
    private bool wasGrounded = false;
    private float lastFacingDirection = 1f;
    private float velocityYLastFrame = 0f;
    private bool justFinishedClimb = false;

    // ── Climb States ─────────────────────────────────────────────────────
    private enum LedgeState { None, Hanging, ClimbingUp, LeapingOff }
    private enum PlatformState { None, Hanging, ClimbingUp }

    private LedgeState ledgeState = LedgeState.None;
    private PlatformState platformState = PlatformState.None;

    // Ledge Vars
    private LedgeAnchor activeLedge;
    private Vector2 ledgeCorner;
    private float ledgeFacingDir;
    private float ledgeClimbTimer;
    private Vector2 ledgeClimbStart;
    private Vector2 ledgeClimbEnd;

    // Platform Vars
    private PlatformAnchor activePlatform;
    private float platformClimbTimer;
    private Vector2 platformClimbStart;
    private Vector2 platformClimbEnd;

    // ── Public API ──────────────────────────────────────────
    public void SetCombatLock(bool locked)
    {
        combatLocked = locked;
        if (locked) rb.linearVelocity = new Vector2(0f, rb.linearVelocity.y);
    }

    public float LastFacingDirection => lastFacingDirection;

    public bool CanAttack => !isRolling
                             && ledgeState == LedgeState.None
                             && platformState == PlatformState.None
                             && !isStunned
                             && !isRollStunned
                             && !isCrouching
                             && CheckGrounded();

    public void Respawn(Vector2 spawnPosition)
    {
        transform.position = spawnPosition;

        rb.bodyType = RigidbodyType2D.Dynamic;
        rb.linearVelocity = Vector2.zero;
        velocityYLastFrame = 0f;

        ledgeState = LedgeState.None;
        platformState = PlatformState.None;
        isRolling = false;
        isStunned = false;
        isRollStunned = false;
        combatLocked = false;

        grabCoyoteCounter = 0f;
        jumpBufferCounter = 0f;

        col.size = defaultColSize;
        col.offset = defaultColOffset;

        animator.SetBool("isLedgeHanging", false);
        animator.SetBool("isLedgeClimbing", false);
        animator.SetBool("isPlatformHanging", false);
        animator.SetBool("isPlatformClimbing", false);
        animator.SetBool("isRolling", false);
        animator.SetBool("isCrouching", false);
        animator.SetFloat("velocityY", 0f);
    }

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        col = GetComponent<BoxCollider2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        animator = GetComponent<Animator>();

        defaultColSize = col.size;
        defaultColOffset = col.offset;

        rb.bodyType = RigidbodyType2D.Dynamic;
        rb.freezeRotation = true;
        rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
        rb.interpolation = RigidbodyInterpolation2D.Interpolate;

        moveAction = new InputAction("Move");
        moveAction.AddCompositeBinding("1DAxis")
            .With("Negative", "<Keyboard>/a")
            .With("Positive", "<Keyboard>/d")
            .With("Negative", "<Keyboard>/leftArrow")
            .With("Positive", "<Keyboard>/rightArrow");

        jumpAction = new InputAction("Jump", binding: "<Keyboard>/space");
        jumpAction.AddBinding("<Keyboard>/w");
        jumpAction.AddBinding("<Keyboard>/upArrow");

        runAction = new InputAction("Run", binding: "<Keyboard>/shift");
        crouchAction = new InputAction("Crouch", binding: "<Keyboard>/c");

        dropAction = new InputAction("Drop", binding: "<Keyboard>/s");
        dropAction.AddBinding("<Keyboard>/downArrow");

        rollAction = new InputAction("Roll", binding: "<Keyboard>/q");
    }

    private void OnEnable()
    {
        moveAction.Enable(); jumpAction.Enable(); runAction.Enable();
        crouchAction.Enable(); dropAction.Enable(); rollAction.Enable();
    }

    private void OnDisable()
    {
        moveAction.Disable(); jumpAction.Disable(); runAction.Disable();
        crouchAction.Disable(); dropAction.Disable(); rollAction.Disable();
    }

    private void Update()
    {
        if (ledgeState != LedgeState.None)
        {
            HandleLedgeClimbState();
            UpdateAnimations(false);
            return;
        }

        if (platformState != PlatformState.None)
        {
            HandlePlatformState();
            UpdateAnimations(false);
            return;
        }

        bool isGrounded = CheckGrounded();

        // ── Input Buffering Triggers ──────────────────────────────────────────
        if (jumpAction.WasPressedThisFrame())
        {
            jumpBufferCounter = jumpBufferThreshold; // Buffer the jump for when we land
            grabCoyoteCounter = grabCoyoteThreshold; // Buffer the grab frame to allow "coyote grabs"
            //Play SFX
            SoundFXManager.instance.PlaySoundFXClip(jumpSoundClip, transform, 1f);
        }
        else
        {
            jumpBufferCounter -= Time.deltaTime;
            grabCoyoteCounter -= Time.deltaTime;
        }
        // ──────────────────────────────────────────────────────────────────────

        if (!wasGrounded && isGrounded)
        {
            if (velocityYLastFrame <= landVelocityThreshold)
            {
                animator.ResetTrigger("Land");
                animator.SetTrigger("Land");
                isStunned = true;
                stunTimeCounter = stunDuration;
            }
            else
            {
                animator.ResetTrigger("SoftLand");
                animator.SetTrigger("SoftLand");
            }
            animator.SetFloat("velocityY", 0f);
        }

        if (isStunned)
        {
            stunTimeCounter -= Time.deltaTime;
            rb.linearVelocity = Vector2.zero;
            if (stunTimeCounter <= 0f) isStunned = false;
        }

        if (isKnockedBack)
        {
            knockbackTimer -= Time.deltaTime;
            if (knockbackTimer <= 0f) isKnockedBack = false;
        }

        if (isRollStunned)
        {
            rollEndStunCounter -= Time.deltaTime;
            rb.linearVelocity = new Vector2(0f, rb.linearVelocity.y);
            if (rollEndStunCounter <= 0f) isRollStunned = false;
        }

        bool anyStun = isStunned || isRollStunned || isKnockedBack;
        if (!anyStun && !combatLocked)
        {
            // Only try grab systems while airborne
            if (!isGrounded)
            {
                // Attempt platform grab first. If successful, it consumes grabCoyoteCounter
                if (!TryGrabPlatform())
                {
                    TryGrabLedge();
                }
            }

            HandleRolling(isGrounded);

            if (!isRolling)
            {
                HandleCrouchState();
                ApplyMovement();
                ApplyJumpPhysics(isGrounded);
            }
        }

        UpdateAnimations(isGrounded);

        velocityYLastFrame = rb.linearVelocity.y;
        wasGrounded = isGrounded;
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  PLATFORM GRAB & CLIMB
    // ═════════════════════════════════════════════════════════════════════════

    private bool TryGrabPlatform()
    {
        // Allow the grab if the grab coyote window is still active
        if (grabCoyoteCounter <= 0f) return false;

        Vector2 headBoxCenter = new Vector2(
            col.bounds.center.x + platformGrabBoxOffset.x,
            col.bounds.center.y + platformGrabBoxOffset.y
        );

        Collider2D[] hits = Physics2D.OverlapBoxAll(headBoxCenter, platformGrabBoxSize, 0f);

        foreach (Collider2D hit in hits)
        {
            if (hit.TryGetComponent<PlatformAnchor>(out PlatformAnchor anchor))
            {
                if (col.bounds.min.y >= hit.bounds.max.y) continue;

                activePlatform = anchor;
                platformState = PlatformState.Hanging;

                rb.linearVelocity = Vector2.zero;
                rb.bodyType = RigidbodyType2D.Kinematic;

                transform.position = new Vector2(
                    transform.position.x + platformHangOffset.x,
                    activePlatform.SurfaceY + platformHangOffset.y
                );

                animator.SetBool("isPlatformHanging", true);

                // Consume grab inputs
                grabCoyoteCounter = 0f;
                jumpBufferCounter = 0f;
                return true;
            }
        }
        return false;
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  LEDGE GRAB & CLIMB
    // ═════════════════════════════════════════════════════════════════════════

    private void TryGrabLedge()
    {
        // Allow the grab if the grab coyote window is still active
        if (grabCoyoteCounter <= 0f) return;

        Vector2 handPos = new Vector2(
            col.bounds.center.x + (lastFacingDirection * ((ledgeGrabBoxSize.x * 0.5f) + ledgeGrabBoxOffset.x)),
            col.bounds.max.y + ledgeGrabBoxOffset.y
        );

        Collider2D[] hits = Physics2D.OverlapBoxAll(handPos, ledgeGrabBoxSize, 0f);

        LedgeAnchor best = null;
        float bestDist = float.MaxValue;

        foreach (Collider2D hit in hits)
        {
            LedgeAnchor anchor = hit.GetComponent<LedgeAnchor>();
            if (anchor == null) continue;
            if (anchor.FacingDir != lastFacingDirection) continue;

            float dist = Vector2.Distance(handPos, anchor.Corner);
            if (dist < bestDist)
            {
                bestDist = dist;
                best = anchor;
            }
        }

        if (best == null) return;

        activeLedge = best;
        ledgeCorner = best.Corner;
        ledgeFacingDir = best.FacingDir;
        ledgeState = LedgeState.Hanging;

        rb.linearVelocity = Vector2.zero;
        rb.bodyType = RigidbodyType2D.Kinematic;

        transform.position = new Vector2(
            ledgeCorner.x - ledgeFacingDir * hangOffset.x,
            ledgeCorner.y + hangOffset.y);

        spriteRenderer.flipX = (ledgeFacingDir < 0f);
        lastFacingDirection = ledgeFacingDir;

        animator.SetBool("isLedgeHanging", true);

        // Consume grab inputs
        grabCoyoteCounter = 0f;
        jumpBufferCounter = 0f;
    }

    private void HandleLedgeClimbState()
    {
        switch (ledgeState)
        {
            case LedgeState.Hanging:
                rb.linearVelocity = Vector2.zero;

                if (dropAction.WasPressedThisFrame())
                {
                    ledgeState = LedgeState.None;
                    rb.bodyType = RigidbodyType2D.Dynamic;
                    rb.linearVelocity = Vector2.zero;
                    animator.SetBool("isLedgeHanging", false);
                    animator.SetFloat("velocityY", 0f);
                    return;
                }

                if (!jumpAction.WasPressedThisFrame()) return;

                float moveInput = moveAction.ReadValue<float>();
                bool pressedAway = (moveInput != 0f) && (Mathf.Sign(moveInput) != Mathf.Sign(ledgeFacingDir));

                if (pressedAway)
                {
                    ledgeState = LedgeState.LeapingOff;
                    rb.bodyType = RigidbodyType2D.Dynamic;
                    rb.linearVelocity = new Vector2(-ledgeFacingDir * leapBackSpeedX, leapBackSpeedY);
                    lastFacingDirection = -ledgeFacingDir;
                    spriteRenderer.flipX = (ledgeFacingDir > 0f);

                    animator.SetBool("isLedgeHanging", false);
                    animator.SetFloat("velocityY", leapBackSpeedY);
                    return;
                }

                if (!activeLedge.isClimbable) return;

                ledgeState = LedgeState.ClimbingUp;
                ledgeClimbTimer = 0f;
                ledgeClimbStart = transform.position;
                ledgeClimbEnd = new Vector2(
                    ledgeCorner.x + ledgeFacingDir * landOffset.x,
                    ledgeCorner.y + landOffset.y);

                animator.SetBool("isLedgeHanging", false);
                animator.SetBool("isLedgeClimbing", true);
                break;

            case LedgeState.ClimbingUp:
                ledgeClimbTimer += Time.deltaTime;
                float tLedge = Mathf.Clamp01(ledgeClimbTimer / climbDuration);

                float tY = Mathf.SmoothStep(0f, 1f, Mathf.Clamp01(tLedge * 1.4f));
                float tX = Mathf.SmoothStep(0f, 1f, Mathf.Clamp01((tLedge - 0.3f) / 0.7f));

                transform.position = new Vector2(
                    Mathf.Lerp(ledgeClimbStart.x, ledgeClimbEnd.x, tX),
                    Mathf.Lerp(ledgeClimbStart.y, ledgeClimbEnd.y, tY));

                if (tLedge >= 1f)
                {
                    ledgeState = LedgeState.None;
                    rb.bodyType = RigidbodyType2D.Dynamic;
                    rb.linearVelocity = Vector2.zero;
                    transform.position = ledgeClimbEnd;

                    justFinishedClimb = true;
                    animator.SetBool("isLedgeClimbing", false);
                    animator.SetBool("isGrounded", true);
                    animator.ResetTrigger("SoftLand");
                    animator.SetTrigger("SoftLand");
                    animator.SetFloat("velocityY", 0f);
                }
                break;

            case LedgeState.LeapingOff:
                if (rb.linearVelocity.y > 0f)
                    rb.linearVelocity += Vector2.up * Physics2D.gravity.y * (riseMultiplier - 1f) * Time.deltaTime;
                else if (rb.linearVelocity.y < 0f)
                    rb.linearVelocity += Vector2.up * Physics2D.gravity.y * (fallMultiplier - 1f) * Time.deltaTime;

                TryGrabLedge();
                if (ledgeState != LedgeState.LeapingOff) return;

                if (CheckGrounded())
                {
                    ledgeState = LedgeState.None;
                    animator.ResetTrigger("SoftLand");
                    animator.SetTrigger("SoftLand");
                    animator.SetFloat("velocityY", 0f);
                }
                break;
        }
    }

    private void HandlePlatformState()
    {
        switch (platformState)
        {
            case PlatformState.Hanging:
                rb.linearVelocity = Vector2.zero;

                if (dropAction.WasPressedThisFrame())
                {
                    platformState = PlatformState.None;
                    rb.bodyType = RigidbodyType2D.Dynamic;
                    animator.SetBool("isPlatformHanging", false);
                    animator.SetFloat("velocityY", 0f);
                    return;
                }

                if (jumpAction.WasPressedThisFrame())
                {
                    platformState = PlatformState.ClimbingUp;
                    platformClimbTimer = 0f;
                    platformClimbStart = transform.position;

                    platformClimbEnd = new Vector2(
                        transform.position.x + (lastFacingDirection * platformLandOffset.x),
                        activePlatform.SurfaceY + platformLandOffset.y
                    );

                    animator.SetBool("isPlatformHanging", false);
                    animator.SetBool("isPlatformClimbing", true);
                }
                break;

            case PlatformState.ClimbingUp:
                platformClimbTimer += Time.deltaTime;
                float t = Mathf.Clamp01(platformClimbTimer / platformClimbDuration);
                float easeT = Mathf.SmoothStep(0f, 1f, t);

                transform.position = Vector2.Lerp(platformClimbStart, platformClimbEnd, easeT);

                if (t >= 1f)
                {
                    platformState = PlatformState.None;
                    rb.bodyType = RigidbodyType2D.Dynamic;
                    rb.linearVelocity = Vector2.zero;

                    animator.SetBool("isPlatformClimbing", false);
                    justFinishedClimb = true;
                }
                break;
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  GIZMOS & MOVEMENT HELPERS
    // ═════════════════════════════════════════════════════════════════════════

    private void OnDrawGizmosSelected()
    {
        if (col == null) return;

        Vector2 handPos = new Vector2(
            col.bounds.center.x + (lastFacingDirection * ((ledgeGrabBoxSize.x * 0.5f) + ledgeGrabBoxOffset.x)),
            col.bounds.max.y + ledgeGrabBoxOffset.y
        );
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireCube(handPos, ledgeGrabBoxSize);

        Vector2 headBoxCenter = new Vector2(
            col.bounds.center.x + platformGrabBoxOffset.x,
            col.bounds.center.y + platformGrabBoxOffset.y
        );
        Gizmos.color = Color.cyan;
        Gizmos.DrawWireCube(headBoxCenter, platformGrabBoxSize);
    }

    private void HandleRolling(bool isGrounded)
    {
        if (rollAction.WasPressedThisFrame() && !isRolling && isGrounded && !isCrouching)
        {
            isRolling = true;
            rollTimeCounter = 0f;
            animator.SetTrigger("Roll");

            float rollHeight = defaultColSize.y - rollHeightDecrement;
            col.size = new Vector2(defaultColSize.x, rollHeight);
            col.offset = new Vector2(defaultColOffset.x, defaultColOffset.y - rollHeightDecrement / 2f);
        }

        if (isRolling)
        {
            rollTimeCounter += Time.deltaTime;
            float t = Mathf.Clamp01(rollTimeCounter / rollDuration);
            float speedCurve = Mathf.Sin(t * Mathf.PI);
            rb.linearVelocity = new Vector2(lastFacingDirection * rollSpeed * speedCurve, rb.linearVelocity.y);

            if (rollTimeCounter >= rollDuration)
            {
                isRolling = false;
                rb.linearVelocity = new Vector2(0f, rb.linearVelocity.y);
                isRollStunned = true;
                rollEndStunCounter = rollEndStunDuration;

                if (CheckCeiling())
                {
                    isCrouching = true;
                    float newHeight = defaultColSize.y - crouchHeightDecrement;
                    col.size = new Vector2(defaultColSize.x, newHeight);
                    col.offset = new Vector2(defaultColOffset.x, defaultColOffset.y - crouchHeightDecrement / 2f);
                }
                else
                {
                    col.size = defaultColSize;
                    col.offset = defaultColOffset;
                }
            }
        }
    }

    private void HandleCrouchState()
    {
        if (!crouchAction.WasPressedThisFrame()) return;

        if (isCrouching)
        {
            if (CheckCeiling()) return;
            isCrouching = false;
            col.size = defaultColSize;
            col.offset = defaultColOffset;
        }
        else
        {
            isCrouching = true;
            float newHeight = defaultColSize.y - crouchHeightDecrement;
            col.size = new Vector2(defaultColSize.x, newHeight);
            col.offset = new Vector2(defaultColOffset.x, defaultColOffset.y - crouchHeightDecrement / 2f);
        }
    }

    private void ApplyMovement()
    {
        float moveInput = moveAction.ReadValue<float>();

        if (moveInput > 0f) lastFacingDirection = 1f;
        else if (moveInput < 0f) lastFacingDirection = -1f;

        float speed = isAiming ? (walkSpeed * 0.4f) :
                      isCrouching ? crouchSpeed :
                      runAction.IsPressed() ? runSpeed : walkSpeed;

        rb.linearVelocity = new Vector2(moveInput * speed, rb.linearVelocity.y);

        if (moveInput > 0f) spriteRenderer.flipX = false;
        else if (moveInput < 0f) spriteRenderer.flipX = true;
    }

    private void ApplyJumpPhysics(bool isGrounded)
    {
        // Normal jump uses your ground jump buffer window
        if (jumpBufferCounter > 0f && isGrounded && !isCrouching)
        {
            rb.linearVelocity = new Vector2(rb.linearVelocity.x, jumpForce);
            jumpBufferCounter = 0f;
            grabCoyoteCounter = 0f; // Prevent instantly snapping to overhead stuff
        }
        // Apply dynamic gravity modifiers
        if (rb.linearVelocity.y > 0f)
            rb.linearVelocity += Vector2.up * Physics2D.gravity.y * (riseMultiplier - 1f) * Time.deltaTime;
        else if (rb.linearVelocity.y < 0f)
            rb.linearVelocity += Vector2.up * Physics2D.gravity.y * (fallMultiplier - 1f) * Time.deltaTime;
    }

    private void UpdateAnimations(bool isGrounded)
    {
        bool anyStun = isStunned || isRollStunned || isKnockedBack;
        bool isWalking = Mathf.Abs(rb.linearVelocity.x) > 0.1f && !isRolling && !anyStun && platformState == PlatformState.None;
        bool isRunning = runAction.IsPressed() && isWalking && !isCrouching;

        bool groundedForAnim = isGrounded || justFinishedClimb;
        if (justFinishedClimb && isGrounded) justFinishedClimb = false;

        animator.SetBool("isWalking", isWalking);
        animator.SetBool("isRunning", isRunning);
        animator.SetBool("isCrouching", isCrouching);
        animator.SetBool("isRolling", isRolling);
        animator.SetBool("isGrounded", groundedForAnim);
        animator.SetFloat("velocityY", rb.linearVelocity.y);

        animator.SetBool("isStunned", isStunned || isKnockedBack);
    }

    private bool CheckGrounded()
    {
        if (rb.linearVelocity.y > 0.1f) return false;

        Vector2 boxCenter = new Vector2(col.bounds.center.x, col.bounds.min.y - 0.05f);
        Vector2 boxSize = new Vector2(col.bounds.size.x * 0.9f, 0.1f);

        foreach (Collider2D c in Physics2D.OverlapBoxAll(boxCenter, boxSize, 0f))
        {
            if (c == col || c.isTrigger) continue;

            if (c.TryGetComponent<PlatformEffector2D>(out PlatformEffector2D effector))
            {
                if (col.bounds.min.y < c.bounds.max.y - 0.1f) continue;
            }
            return true;
        }
        return false;
    }

    private bool CheckCeiling()
    {
        Vector2 boxCenter = new Vector2(col.bounds.center.x, col.bounds.max.y + crouchHeightDecrement / 2f);
        Vector2 boxSize = new Vector2(col.bounds.size.x * 0.9f, crouchHeightDecrement);

        foreach (Collider2D c in Physics2D.OverlapBoxAll(boxCenter, boxSize, 0f))
        {
            if (c == col || c.isTrigger) continue;
            if (c.GetComponent<PlatformEffector2D>() != null) continue;

            return true;
        }
        return false;
    }

    // ── Combat & Damage Reactions ─────────────────────────────────────────────
    public void ApplyKnockback(Vector2 force, float duration)
    {
        isKnockedBack = true;
        knockbackTimer = duration;

        SetCombatLock(false);
        ledgeState = LedgeState.None;
        platformState = PlatformState.None;
        animator.SetBool("isLedgeHanging", false);
        animator.SetBool("isPlatformHanging", false);

        rb.bodyType = RigidbodyType2D.Dynamic;
        rb.linearVelocity = force;
    }

    public void ApplyStatusStun(float duration)
    {
        isKnockedBack = true;
        knockbackTimer = duration;

        SetCombatLock(false);
        ledgeState = LedgeState.None;
        platformState = PlatformState.None;
        animator.SetBool("isLedgeHanging", false);
        animator.SetBool("isPlatformHanging", false);

        rb.bodyType = RigidbodyType2D.Dynamic;
        rb.linearVelocity = Vector2.zero;
    }
}