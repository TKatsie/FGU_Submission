using UnityEngine;

[RequireComponent(typeof(Collider2D))]
public class PlatformAnchor : MonoBehaviour
{
    private Collider2D platformCollider;

    private void Awake()
    {
        platformCollider = GetComponent<Collider2D>();
    }

    /// <summary>
    /// Returns the exact Y-coordinate of the platform's top surface.
    /// </summary>
    public float SurfaceY
    {
        get
        {
            if (platformCollider == null)
            {
                platformCollider = GetComponent<Collider2D>();
            }
            return platformCollider.bounds.max.y;
        }
    }
}