using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

[RequireComponent(typeof(RetroPlayerController))]
public class PlayerHealth : MonoBehaviour, IDamageable
{
    [Header("Health Settings")]
    public int maxHealth = 100;
    private int currentHealth;

    [Header("Respawn / Spawn Settings")]
    public Transform respawnPoint;
    private Vector3 fallbackStartPos;

    [Header("UI Components")]
    public Slider healthSlider;
    public TextMeshProUGUI healthPercentText;

    [Header("Custom Knockback Tuning")]
    public float knockbackHorizontalRange = 14f;
    public float knockbackUpwardForce = 12f;
    public float knockbackStunDuration = 0.35f;
    public float iFrameDuration = 0.6f;
    private float iFrameTimer = 0f;

    [Header("Visual Flash Settings")]
    [Tooltip("The color the sprite will tint if no special flash material is used.")]
    public Color hurtTint = Color.red;
    [Tooltip("How many times the sprite blinks off and on when hurt.")]
    public int flashCount = 4;
    [Tooltip("How long each flash phase lasts (in seconds).")]
    public float flashPeriod = 0.08f;

    [Tooltip("OPTIONAL: Assign a material with a flat white silhouette shader here for a true white flash.")]
    public Material whiteFlashMaterial;

    private RetroPlayerController controller;
    private SpriteRenderer spriteRenderer;
    private Material originalMaterial;
    private Coroutine flashCoroutine;
    // --- DOT Tracking Variables ---
    private float dotTimer = 0f;
    private float dotTickTimer = 0f;
    private int currentDotDamage;
    private float currentDotTickRate;
    private bool currentDotStuns;
    private float currentDotStunDur;
    [SerializeField] AudioClip damageSFX;

    private void Awake()
    {
        controller = GetComponent<RetroPlayerController>();
        // Grab the SpriteRenderer from this object or its visual children
        spriteRenderer = GetComponentInChildren<SpriteRenderer>();

        if (spriteRenderer != null)
        {
            originalMaterial = spriteRenderer.material;
        }

        currentHealth = maxHealth;
        fallbackStartPos = transform.position;
        UpdateVisualUI();
    }

    private void Update()
    {
        if (iFrameTimer > 0)
        {
            iFrameTimer -= Time.deltaTime;
        }

        // NEW: Background DOT Timer
        if (dotTimer > 0)
        {
            dotTimer -= Time.deltaTime;
            dotTickTimer -= Time.deltaTime;

            if (dotTickTimer <= 0f)
            {
                // Reset the tick timer and apply the damage!
                dotTickTimer = currentDotTickRate;
                TakeDOTDamage();
            }
        }
    }

    public void TakeDamageHit(int amount, Vector3 damageSourcePosition, Vector2 incomingKnockbackForce, float incomingStunTime)
    {
        if (iFrameTimer > 0 || currentHealth <= 0) return;

        currentHealth -= amount;
        currentHealth = Mathf.Clamp(currentHealth, 0, maxHealth);
        iFrameTimer = iFrameDuration;

        // Play damage sound effect
        if (damageSFX != null && SoundFXManager.instance != null)
        {
            SoundFXManager.instance.PlaySoundFXClip(damageSFX, transform, 1f);
        }

        UpdateVisualUI();

        if (currentHealth <= 0)
        {
            Die();
            return;
        }

        if (flashCoroutine != null) StopCoroutine(flashCoroutine);
        flashCoroutine = StartCoroutine(FlashSpriteRoutine());

        // Only apply knockback if the trap requested it
        if (incomingKnockbackForce != Vector2.zero)
        {
            float horizontalDirection = Mathf.Sign(transform.position.x - damageSourcePosition.x);
            if (horizontalDirection == 0) horizontalDirection = 1f;

            Vector2 finalForce = new Vector2(horizontalDirection * incomingKnockbackForce.x, incomingKnockbackForce.y);
            controller.ApplyKnockback(finalForce, incomingStunTime);
        }
    }

    public void TakeDamage(int amount)
    {
        // Interface fallback: Pass Vector2.zero for force and 0f for stun duration[cite: 8]
        TakeDamageHit(amount, transform.position, Vector2.zero, 0f);
    }

    // --- ADD THIS DOT METHOD AND COROUTINE ---
    public void ApplyDOT(int dmg, float duration, float tickRate, bool causesStun, float stunDur)
    {
        // If the player wasn't taking DOT before, force the first tick to happen instantly
        if (dotTimer <= 0f)
        {
            dotTickTimer = 0f;
        }

        // Refresh the total duration back to max (e.g., 10 seconds)
        // This ensures the 10-second timer doesn't actually start counting down until they leave the fog!
        dotTimer = duration;

        currentDotDamage = dmg;
        currentDotTickRate = tickRate;
        currentDotStuns = causesStun;
        currentDotStunDur = stunDur;
    }

    private void TakeDOTDamage()
    {
        if (currentHealth <= 0) return;

        currentHealth -= currentDotDamage;
        currentHealth = Mathf.Clamp(currentHealth, 0, maxHealth);
        UpdateVisualUI();

        // Flash the sprite to show DOT damage happened
        if (flashCoroutine != null) StopCoroutine(flashCoroutine);
        flashCoroutine = StartCoroutine(FlashSpriteRoutine());

        // Apply the After-Effect Stun (e.g., Electric Shock)
        if (currentDotStuns)
        {
            controller.ApplyStatusStun(currentDotStunDur);
        }

        if (currentHealth <= 0)
        {
            Die();
        }
    }

    private System.Collections.IEnumerator DOTProcess(int dmg, float duration, float tickRate, bool causesStun, float stunDur)
    {
        float timeElapsed = 0f;

        while (timeElapsed < duration)
        {
            // Wait for the next tick
            yield return new WaitForSeconds(tickRate);
            timeElapsed += tickRate;

            if (currentHealth <= 0) yield break;

            // Apply direct damage (Bypassing i-frames entirely)
            currentHealth -= dmg;
            currentHealth = Mathf.Clamp(currentHealth, 0, maxHealth);
            UpdateVisualUI();

            // Flash the sprite to show DOT damage happened
            if (flashCoroutine != null) StopCoroutine(flashCoroutine);
            flashCoroutine = StartCoroutine(FlashSpriteRoutine());

            // Apply the After-Effect Stun (e.g., Electric Shock)
            if (causesStun)
            {
                controller.ApplyStatusStun(stunDur);
            }

            if (currentHealth <= 0)
            {
                Die();
                yield break;
            }
        }
    }

    private IEnumerator FlashSpriteRoutine()
    {
        if (spriteRenderer == null) yield break;

        for (int i = 0; i < flashCount; i++)
        {
            // HURT PHASE: Swap material OR change color tint
            if (whiteFlashMaterial != null)
            {
                spriteRenderer.material = whiteFlashMaterial;
            }
            else
            {
                spriteRenderer.color = hurtTint;
            }

            yield return new WaitForSeconds(flashPeriod);

            // NORMAL PHASE: Revert instantly back to defaults
            spriteRenderer.material = originalMaterial;
            spriteRenderer.color = Color.white;

            yield return new WaitForSeconds(flashPeriod);
        }
    }

    private void UpdateVisualUI()
    {
        if (healthSlider != null)
        {
            healthSlider.maxValue = maxHealth;
            healthSlider.value = currentHealth;
        }

        if (healthPercentText != null)
        {
            float healthPercentage = ((float)currentHealth / maxHealth) * 100f;
            healthPercentText.text = $"{Mathf.CeilToInt(healthPercentage)}%";
        }
    }

    private void Die()
    {
        // Stop any active visual flash loops on death
        if (flashCoroutine != null) StopCoroutine(flashCoroutine);

        if (spriteRenderer != null)
        {
            spriteRenderer.material = originalMaterial;
            spriteRenderer.color = Color.white;
        }

        currentHealth = maxHealth;
        UpdateVisualUI();

        Vector3 spawnDestination = respawnPoint != null ? respawnPoint.position : fallbackStartPos;
        controller.Respawn(spawnDestination);
    }
}