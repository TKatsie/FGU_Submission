using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(Rigidbody2D))]
[DisallowMultipleComponent] // Prevents accidentally adding two movement scripts
public class PlayerPlatformer : MonoBehaviour
{
    [Header("Movement Settings")]
    [SerializeField] private float maxSpeed = 8f;
    [SerializeField] private float acceleration = 60f;
    [SerializeField] private float deceleration = 60f;

    [Header("Jump Settings")]
    [SerializeField] private float jumpForce = 14f;
    [SerializeField] private float fallGravityMultiplier = 2.5f; // Makes falling feel heavy and realistic

    [Header("Ground Detection")]
    [SerializeField] private Transform groundCheckPoint;
    [SerializeField] private Vector2 groundCheckSize = new Vector2(0.5f, 0.1f);
    [SerializeField] private LayerMask groundLayer;

    private Rigidbody2D rb;
    private float moveInput;
    private bool isGrounded;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();

        // FORCED DEPENDENCIES: The script configures its own safety net
        rb.gravityScale = 2f;
        rb.freezeRotation = true; // No bowling ball rolling!
        rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous; // Prevents phasing through floors
    }

    void Update()
    {
        // 1. Independent Ground Check (Ignores buggy collision events)
        if (groundCheckPoint != null)
        {
            isGrounded = Physics2D.OverlapBox(groundCheckPoint.position, groundCheckSize, 0f, groundLayer);
        }

        // 2. Modern Input System Polling (No extra assets required)
        moveInput = 0f;
        if (Keyboard.current != null)
        {
            if (Keyboard.current.aKey.isPressed || Keyboard.current.leftArrowKey.isPressed) moveInput = -1f;
            if (Keyboard.current.dKey.isPressed || Keyboard.current.rightArrowKey.isPressed) moveInput = 1f;

            // Jump Detection
            if (Keyboard.current.spaceKey.wasPressedThisFrame && isGrounded)
            {
                Jump();
            }
        }
    }

    void FixedUpdate()
    {
        // 3. Dynamic Physics Acceleration (Smooth startup and stopping)
        float targetSpeed = moveInput * maxSpeed;
        float speedDifference = targetSpeed - rb.linearVelocity.x;
        float accelRate = (Mathf.Abs(targetSpeed) > 0.01f) ? acceleration : deceleration;

        rb.AddForce(speedDifference * accelRate * Vector2.right * Time.fixedDeltaTime, ForceMode2D.Force);

        // 4. Realistic Gravity Modification (Fast falling)
        if (rb.linearVelocity.y < 0)
        {
            // Apply extra downward force ONLY when falling for that crisp arcade feel
            rb.linearVelocity += Vector2.up * Physics2D.gravity.y * (fallGravityMultiplier - 1) * Time.fixedDeltaTime;
        }
    }

    private void Jump()
    {
        // Cancel out any downward momentum before jumping to guarantee consistent jump heights
        rb.linearVelocity = new Vector2(rb.linearVelocity.x, 0f);
        rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
    }

    // 5. Visual Debugging: Draws a box in the editor to help you align the ground check
    private void OnDrawGizmosSelected()
    {
        if (groundCheckPoint != null)
        {
            Gizmos.color = Color.green;
            Gizmos.DrawWireCube(groundCheckPoint.position, groundCheckSize);
        }
    }
}