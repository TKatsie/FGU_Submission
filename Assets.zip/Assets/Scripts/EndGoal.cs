using UnityEngine;

public class EndGoal : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D collision)
    {
        // Stop the timer if the object touching us has the player controller
        if (collision.GetComponent<RetroPlayerController>() != null)
        {
            if (GameTimer.Instance != null)
            {
                GameTimer.Instance.StopTimer();
            }
        }
    }
}