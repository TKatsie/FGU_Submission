using UnityEngine;
using TMPro; // If using legacy text, replace with: using UnityEngine.UI;

public class GameTimer : MonoBehaviour
{
    public static GameTimer Instance;

    [Header("UI References")]
    public TextMeshProUGUI timerText; // Change to 'public Text timerText;' if legacy

    private float elapsedTime = 0f;
    private bool isRunning = true;

    private void Awake()
    {
        // Setup Singleton instance for easy access
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    private void Update()
    {
        if (isRunning)
        {
            elapsedTime += Time.deltaTime;
            DisplayTime(elapsedTime);
        }
    }

    private void DisplayTime(float timeToDisplay)
    {
        float minutes = Mathf.FloorToInt(timeToDisplay / 60);
        float seconds = Mathf.FloorToInt(timeToDisplay % 60);
        float milliseconds = (timeToDisplay % 1) * 100; // 2 digits for milliseconds looks cleaner

        // Formats to 00:00:00
        timerText.text = string.Format("{0:00}:{1:00}:{2:02}", minutes, seconds, milliseconds);
    }

    public void StopTimer()
    {
        isRunning = false;
    }
}