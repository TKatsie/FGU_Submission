using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuLevelLoader : MonoBehaviour
{
    public Animator transition;
    public float transitionTime = 1f;

    void Update()
    {
        if(Input.GetMouseButtonDown(0))
        {
            LoadNextLevel();
        }
    }

    public void LoadNextLevel()
    {
        StartCoroutine(LoadLevel(SceneManager.GetActiveScene().buildIndex + 1));
    }

    IEnumerator LoadLevel(int levelIndex)
    {
        // Trigger your fade-out animation
        if (transition != null)
        {
            transition.SetTrigger("Start");
        }
        // Wait for the transition to finish
        yield return new WaitForSeconds(transitionTime);
        // Load the next scene by build index
        SceneManager.LoadScene(levelIndex);
    }
}