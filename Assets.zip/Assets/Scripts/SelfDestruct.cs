using UnityEngine;

public class SelfDestruct : MonoBehaviour
{
    [Header("Timing Framework")]
    [Tooltip("How long the trap actively spawns smoke and inflicts damage.")]
    public float activeDuration = 3f;

    [Tooltip("Extra time allowed for lingering particles to die naturally before the object is deleted from RAM.")]
    public float fadeDuration = 3f;

    private ParticleSystem particles;
    private DamageArea damageArea;
    private float timer = 0f;
    private bool hasStoppedActiveState = false;

    private void Start()
    {
        // Automatically find the components on this object or its children
        particles = GetComponentInChildren<ParticleSystem>();
        damageArea = GetComponentInChildren<DamageArea>();
    }

    private void Update()
    {
        timer += Time.deltaTime;

        // 1. End of the active phase
        if (!hasStoppedActiveState && timer >= activeDuration)
        {
            hasStoppedActiveState = true;

            // Stop generating NEW smoke puffs, but don't delete existing ones
            if (particles != null)
            {
                particles.Stop(true, ParticleSystemStopBehavior.StopEmitting);
            }

            // Turn off the damage zone so the fading smoke is purely visual and harmless
            if (damageArea != null)
            {
                damageArea.enabled = false;
            }
        }

        // 2. Ultimate cleanup crew cleanup
        if (timer >= (activeDuration + fadeDuration))
        {
            Destroy(gameObject);
        }
    }
}