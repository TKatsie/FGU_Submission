﻿using UnityEngine;

// Place this on a standalone prefab at the exact corner of any climbable ledge.
// Position it at the TOP EDGE of the wall tile, right at the corner.
// Set Side to match which side of the wall is climbable.
//
//   Right ledge (wall is to the RIGHT of open air):
//       XX
//       PL   ← anchor here, Side = Right
//
//   Left ledge (wall is to the LEFT of open air):
//       XX
//       LP   ← anchor here, Side = Left

public class LedgeAnchor : MonoBehaviour
{
    public enum LedgeSide { Left, Right }

    [Tooltip("Right = wall is on the right, player approaches from the left.\n" +
             "Left  = wall is on the left,  player approaches from the right.")]
    public LedgeSide side = LedgeSide.Right;

    [Tooltip("Can the player climb up onto this ledge?\n" +
             "Uncheck for ledges with no room on top, or hang-only spots.")]
    public bool isClimbable = true;

    // Facing direction as a float (+1 or -1) for use by the player controller.
    // Right ledge → player faces right (+1) to grab it.
    public float FacingDir => side == LedgeSide.Right ? 1f : -1f;

    // The world-space corner position is just this transform's position.
    public Vector2 Corner => transform.position;

    // ── Editor visualisation ──────────────────────────────────────────────────
    private void OnDrawGizmos()
    {
        // Green = climbable, Orange = hang-only
        Gizmos.color = isClimbable ? Color.green : new Color(1f, 0.5f, 0f);

        // Draw a small diamond at the anchor point
        float s = 0.12f;
        Vector3 p = transform.position;
        Gizmos.DrawLine(p + Vector3.up * s, p + Vector3.right * s);
        Gizmos.DrawLine(p + Vector3.right * s, p + Vector3.down * s);
        Gizmos.DrawLine(p + Vector3.down * s, p + Vector3.left * s);
        Gizmos.DrawLine(p + Vector3.left * s, p + Vector3.up * s);

        // Draw an arrow showing which direction the player approaches from
        float arrowLen = 0.35f;
        float approachDir = side == LedgeSide.Right ? -1f : 1f; // player comes from opposite side
        Vector3 arrowEnd = p + new Vector3(approachDir * arrowLen, 0f);
        Gizmos.DrawLine(p, arrowEnd);
        Gizmos.DrawLine(arrowEnd, arrowEnd + new Vector3(approachDir * -0.08f, 0.08f));
        Gizmos.DrawLine(arrowEnd, arrowEnd + new Vector3(approachDir * -0.08f, -0.08f));

#if UNITY_EDITOR
        // Label in scene view
        UnityEditor.Handles.color = Color.green;
        UnityEditor.Handles.Label(p + Vector3.up * 0.2f, $"Ledge {side}{(isClimbable ? "" : " [hang only]")}");
#endif
    }
}