using UnityEngine;

public class ProximitySpawner : MonoBehaviour
{
    [Header("Activation Hitbox")]
    public Vector2 activationSize = new Vector2(2f, 2f);
    public Vector2 activationOffset = Vector2.zero;
    public LayerMask targetLayer;

    [Header("Fuse Settings")]
    public float fuseDelay = 0f;
    public GameObject prefabToSpawn;

    [Header("Optional Animation Hook")]
    public Animator trapAnimator;
    public string warmingUpTrigger = "isWarmingUp";

    private bool isTriggered = false;
    private float timer = 0f;

    private void Update()
    {
        if (isTriggered)
        {
            timer -= Time.deltaTime;
            if (timer <= 0f) Explode();
            return;
        }

        Vector2 center = (Vector2)transform.position + activationOffset;
        if (Physics2D.OverlapBox(center, activationSize, 0f, targetLayer) != null)
        {
            isTriggered = true;
            timer = fuseDelay;
            if (trapAnimator != null) trapAnimator.SetTrigger(warmingUpTrigger);
        }
    }

    private void Explode()
    {
        // Spawns your explosion/smoke effect
        if (prefabToSpawn != null)
        {
            Instantiate(prefabToSpawn, transform.position, Quaternion.identity);
        }

        // DESTROYS THIS MINE INSTANTLY
        Destroy(gameObject);
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = new Color(0f, 1f, 1f, 0.3f);
        Gizmos.DrawCube((Vector2)transform.position + activationOffset, activationSize);
    }
}