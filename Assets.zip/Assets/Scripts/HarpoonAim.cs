using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(RetroPlayerController))]
public class HarpoonAim : MonoBehaviour
{
    [Header("References")]
    public GameObject harpoonPrefab;
    public Transform throwPoint;
    public LineRenderer aimLine;

    [Header("Dynamic Aim Settings")]
    public float maxThrowForce = 25f;
    public float maxAimDistance = 5f;

    [Header("Curve Visuals")]
    public int trajectorySteps = 45;
    public float stepTime = 0.05f;
    public float lineScrollSpeed = 3f;

    [Header("Cooldown Settings")]
    public float throwCooldown = 1f;
    private float cooldownTimer = 0f;

    private RetroPlayerController controller;
    private bool aiming = false;

    private void Awake()
    {
        controller = GetComponent<RetroPlayerController>();
        if (aimLine != null) aimLine.enabled = false;
    }

    private void Update()
    {
        if (cooldownTimer > 0f) cooldownTimer -= Time.deltaTime;

        if (Mouse.current.rightButton.wasPressedThisFrame && cooldownTimer <= 0f)
        {
            aiming = true;
            controller.isAiming = true;
            if (aimLine != null) aimLine.enabled = true;
        }
        else if (Mouse.current.rightButton.wasReleasedThisFrame && aiming)
        {
            CancelAim();
        }

        if (aiming)
        {
            DrawTrajectory();
            ScrollAimLine();

            if (Mouse.current.leftButton.wasPressedThisFrame)
            {
                ThrowHarpoon();
                CancelAim();
            }
        }
    }

    private void CancelAim()
    {
        aiming = false;
        controller.isAiming = false;
        if (aimLine != null) aimLine.enabled = false;
    }

    private Vector2 CalculateDynamicVelocity()
    {
        Vector3 mousePos = Camera.main.ScreenToWorldPoint(Mouse.current.position.ReadValue());
        mousePos.z = 0f;

        Vector2 aimDirection = (mousePos - throwPoint.position);
        float distance = Mathf.Clamp(aimDirection.magnitude, 0.5f, maxAimDistance);
        float currentForce = (distance / maxAimDistance) * maxThrowForce;

        return aimDirection.normalized * currentForce;
    }

    private void DrawTrajectory()
    {
        if (aimLine == null) return;

        Vector2 velocity = CalculateDynamicVelocity();
        Vector2 currentPos = throwPoint.position;

        aimLine.positionCount = trajectorySteps;

        for (int i = 0; i < trajectorySteps; i++)
        {
            aimLine.SetPosition(i, currentPos);
            velocity.y += Physics2D.gravity.y * stepTime;
            currentPos += velocity * stepTime;
        }
    }

    private void ScrollAimLine()
    {
        if (aimLine == null || !aimLine.enabled) return;
        float offset = Time.time * lineScrollSpeed;
        aimLine.material.SetTextureOffset("_MainTex", new Vector2(-offset, 0f));
    }

    private void ThrowHarpoon()
    {
        Vector2 velocity = CalculateDynamicVelocity();

        // --- NEW: Calculate and apply correct rotation on Frame 0 ---
        float angle = Mathf.Atan2(velocity.y, velocity.x) * Mathf.Rad2Deg;
        Quaternion spawnRotation = Quaternion.AngleAxis(angle, Vector3.forward);

        GameObject harpoon = Instantiate(harpoonPrefab, throwPoint.position, spawnRotation);
        Rigidbody2D rb = harpoon.GetComponent<Rigidbody2D>();

        // --- NEW: Apply scale flip on Frame 0 ---
        if (velocity.x < 0f)
        {
            harpoon.transform.localScale = new Vector3(1f, -1f, 1f);
        }
        else
        {
            harpoon.transform.localScale = new Vector3(1f, 1f, 1f);
        }

        rb.linearVelocity = velocity;
        cooldownTimer = throwCooldown;
    }
}