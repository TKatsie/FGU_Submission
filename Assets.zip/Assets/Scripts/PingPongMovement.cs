using System.Collections;
using UnityEngine;

public class PingPongMovement : MonoBehaviour
{
    [Header("Movement Settings")]
    [Tooltip("How far the trap moves from its starting point.")]
    public Vector2 travelDistance = new Vector2(5f, 0f);

    [Tooltip("How many seconds it takes to travel one way.")]
    public float travelTime = 2f;

    [Tooltip("How long it pauses at the ends before turning around.")]
    public float pauseDuration = 1f;

    private Vector3 startPos;
    private Vector3 endPos;

    private void Start()
    {
        startPos = transform.position;
        endPos = startPos + (Vector3)travelDistance;

        // Start the continuous movement loop
        StartCoroutine(MoveRoutine());
    }

    private IEnumerator MoveRoutine()
    {
        while (true) // Loops infinitely
        {
            yield return StartCoroutine(MoveToPosition(endPos));
            yield return new WaitForSeconds(pauseDuration); // Pause at the end

            yield return StartCoroutine(MoveToPosition(startPos));
            yield return new WaitForSeconds(pauseDuration); // Pause at the start
        }
    }

    private IEnumerator MoveToPosition(Vector3 target)
    {
        Vector3 origin = transform.position;
        float t = 0f;

        while (t < 1f)
        {
            t += Time.deltaTime / travelTime;
            // SmoothStep adds a nice ease-in and ease-out effect to the movement
            float easeT = Mathf.SmoothStep(0f, 1f, t);
            transform.position = Vector3.Lerp(origin, target, easeT);
            yield return null;
        }
        transform.position = target; // Snap exactly to target at the end
    }

    // This draws the path in the Unity Editor!
    private void OnDrawGizmosSelected()
    {
        // If the game is running, draw from the saved start pos. Otherwise, draw from current pos.
        Vector3 gizmoStart = Application.isPlaying ? startPos : transform.position;
        Vector3 gizmoEnd = gizmoStart + (Vector3)travelDistance;

        // Draw a green line showing the path
        Gizmos.color = Color.green;
        Gizmos.DrawLine(gizmoStart, gizmoEnd);

        // Draw spheres at the start and end points
        Gizmos.DrawWireSphere(gizmoStart, 0.2f);
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(gizmoEnd, 0.2f);
    }
}