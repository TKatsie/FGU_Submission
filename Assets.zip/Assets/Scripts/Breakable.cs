﻿using UnityEngine;

// ─────────────────────────────────────────────────────────────────────────────
// Breakable — attach to any prop or destructible object.
//
// How it works:
//   - Has a health pool. Each hit from PlayerCombat reduces it.
//   - Cycles through damage sprites as health drops, giving a visual
//     "nearly broken" appearance before it shatters.
//   - On death: plays a break effect, drops optional loot, then destroys itself.
//
// Setup:
//   1. Create your prop GameObject with a SpriteRenderer and Collider2D.
//   2. Attach this script.
//   3. Fill in the damagedSprites array in order from least → most damaged.
//      Leave it empty if you only have one sprite (it just breaks with no stages).
//   4. Optionally assign a breakParticle prefab and lootPrefab.
// ─────────────────────────────────────────────────────────────────────────────

public class Breakable : MonoBehaviour, IDamageable
{
    [Header("Health")]
    public int maxHealth = 20;
    private int currentHealth;

    [Header("Damage Stages")]
    [Tooltip("Sprites shown as health decreases. Index 0 = first hit, last = nearly broken. " +
             "Leave empty for a single sprite that just disappears on break.")]
    public Sprite[] damagedSprites;

    [Header("On Break")]
    [Tooltip("Optional particle/VFX prefab spawned at this object's position when it breaks.")]
    public GameObject breakParticlePrefab;

    [Tooltip("Optional item/pickup prefab dropped when the object breaks.")]
    public GameObject lootPrefab;

    [Tooltip("How long to wait after the break effect before destroying the object. " +
             "Set to 0 for instant removal.")]
    public float destroyDelay = 0.1f;

    // ── Internals ─────────────────────────────────────────────────────────────
    private SpriteRenderer spriteRenderer;
    private bool broken = false;

    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        currentHealth = maxHealth;
    }

    // ── IDamageable ───────────────────────────────────────────────────────────
    public void TakeDamage(int amount)
    {
        if (broken) return;

        currentHealth -= amount;
        UpdateDamageSprite();

        if (currentHealth <= 0)
            Break();
    }

    // ── Damage Sprite Stages ──────────────────────────────────────────────────
    private void UpdateDamageSprite()
    {
        if (damagedSprites == null || damagedSprites.Length == 0) return;
        if (spriteRenderer == null) return;

        // Map current health percentage to a sprite index.
        // Full health = no sprite change. As health drops, step through sprites.
        float healthPercent = (float)currentHealth / maxHealth;

        // Invert so index 0 = first damage stage, last = nearly broken
        // e.g. 3 sprites, 75% HP → index 0, 50% → index 1, 25% → index 2
        int index = Mathf.FloorToInt((1f - healthPercent) * damagedSprites.Length);
        index = Mathf.Clamp(index, 0, damagedSprites.Length - 1);

        spriteRenderer.sprite = damagedSprites[index];
    }

    // ── Break ─────────────────────────────────────────────────────────────────
    private void Break()
    {
        broken = true;

        // Disable collider immediately so nothing can interact with the corpse
        Collider2D col = GetComponent<Collider2D>();
        if (col != null) col.enabled = false;

        // Spawn break particle effect
        if (breakParticlePrefab != null)
            Instantiate(breakParticlePrefab, transform.position, Quaternion.identity);

        // Drop loot at the same position
        if (lootPrefab != null)
            Instantiate(lootPrefab, transform.position, Quaternion.identity);

        Destroy(gameObject, destroyDelay);
    }

    // ── Editor Preview ────────────────────────────────────────────────────────
    private void OnDrawGizmosSelected()
    {
        // Draw a health bar above the object in Scene view for quick reference
#if UNITY_EDITOR
        if (!Application.isPlaying) return;
        float pct = (float)currentHealth / maxHealth;
        UnityEditor.Handles.color = Color.Lerp(Color.red, Color.green, pct);
        UnityEditor.Handles.DrawLine(
            transform.position + Vector3.up * 0.8f,
            transform.position + Vector3.up * 0.8f + Vector3.right * pct);
#endif
    }
}