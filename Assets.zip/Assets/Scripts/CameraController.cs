﻿using UnityEngine;

public class CameraController : MonoBehaviour
{
    [Header("Target & Base Follow")]
    [SerializeField] private Transform target;
    [SerializeField] private float smoothSpeed = 4f;
    [SerializeField] private Vector3 offset = new Vector3(0f, 0f, -10f);

    [Header("Look-Ahead")]
    [SerializeField] private float lookAheadDistance = 2.5f;
    [SerializeField] private float lookAheadSpeed = 3f;
    [SerializeField] private float lookAheadReturnSpeed = 1.5f;

    [Header("Idle Bob")]
    [SerializeField] private bool enableIdleBob = true;
    [SerializeField] private float bobAmplitudeX = 0.03f;  // Max horizontal drift
    [SerializeField] private float bobAmplitudeY = 0.05f;  // Max vertical drift
    [SerializeField] private float bobFrequency = 0.4f;   // How fast the noise crawls (lower = lazier)
    [SerializeField] private float idleSpeedThreshold = 0.1f;

    // ── Internals ──────────────────────────────────────────────────────────────
    private Rigidbody2D targetRb;
    private float currentLookAhead = 0f;
    private float targetLookAhead = 0f;
    private float lastFacingDir = 1f;
    private float idleTimer = 0f;
    private Vector2 bobOffset = Vector2.zero;

    // Two separate Perlin noise seeds so X and Y drift independently
    // and never mirror each other.
    private float noiseSeedX;
    private float noiseSeedY;

    private void Awake()
    {
        // Randomise seeds at runtime so every play session feels different
        noiseSeedX = Random.Range(0f, 100f);
        noiseSeedY = Random.Range(0f, 100f);
    }

    private void Start()
    {
        if (target != null)
            targetRb = target.GetComponent<Rigidbody2D>();
    }

    private void LateUpdate()
    {
        if (target == null) return;

        float velocityX = targetRb != null ? targetRb.linearVelocity.x : 0f;
        bool isIdle = Mathf.Abs(velocityX) < idleSpeedThreshold;

        // ── 1. Look-Ahead ──────────────────────────────────────────────────────
        if (!isIdle)
        {
            lastFacingDir = Mathf.Sign(velocityX);
            targetLookAhead = lastFacingDir * lookAheadDistance;
        }
        else
        {
            targetLookAhead = 0f;
        }

        float lerpSpeed = (targetLookAhead != 0f) ? lookAheadSpeed : lookAheadReturnSpeed;
        currentLookAhead = Mathf.Lerp(
            currentLookAhead,
            targetLookAhead,
            1f - Mathf.Pow(0.01f, lerpSpeed * Time.deltaTime));

        // ── 2. Dynamic Directional Bob (Perlin noise) ──────────────────────────
        if (enableIdleBob)
        {
            if (isIdle)
            {
                idleTimer += Time.deltaTime;

                // Fade in over ~1s so the bob doesn't pop on the instant you stop
                float fadeIn = Mathf.Clamp01(idleTimer);

                // Mathf.PerlinNoise returns 0–1; remap to -1..1 by subtracting 0.5 and doubling.
                // X and Y use different seed offsets so they drift on completely independent paths.
                float noiseX = (Mathf.PerlinNoise(noiseSeedX + Time.time * bobFrequency, 0f) - 0.5f) * 2f;
                float noiseY = (Mathf.PerlinNoise(0f, noiseSeedY + Time.time * bobFrequency) - 0.5f) * 2f;

                bobOffset = Vector2.Lerp(
                    bobOffset,
                    new Vector2(noiseX * bobAmplitudeX, noiseY * bobAmplitudeY) * fadeIn,
                    1f - Mathf.Pow(0.01f, 6f * Time.deltaTime)); // smooth the noise output too
            }
            else
            {
                // Moving — fade bob back to zero and reset idle timer
                idleTimer = 0f;
                bobOffset = Vector2.Lerp(bobOffset, Vector2.zero,
                    1f - Mathf.Pow(0.01f, 8f * Time.deltaTime));
            }
        }
        else
        {
            bobOffset = Vector2.zero;
        }

        // ── 3. Compose Final Position ──────────────────────────────────────────
        Vector3 targetPos = target.position
                          + offset
                          + new Vector3(currentLookAhead + bobOffset.x, bobOffset.y, 0f);

        transform.position = Vector3.Lerp(
            transform.position,
            targetPos,
            1f - Mathf.Pow(0.01f, smoothSpeed * Time.deltaTime));
    }
}