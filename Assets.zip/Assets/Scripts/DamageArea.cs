using UnityEngine;

public class DamageArea : MonoBehaviour
{
    [Header("Hitbox (Use Gizmos to align)")]
    public Vector2 damageSize = new Vector2(1.5f, 1.5f);
    public Vector2 damageOffset = Vector2.zero;
    public LayerMask targetLayer;

    [Header("Instant Damage")]
    public int instantDamage = 10;
    public bool applyKnockback = true;
    public Vector2 knockbackForce = new Vector2(10f, 12f);
    public float knockbackStunDuration = 0.35f;

    [Header("Damage Over Time (DOT)")]
    public bool applyDOT = false;
    public int dotDamage = 1;
    public float dotDuration = 10f;
    public float dotTickRate = 2f;
    public bool dotCausesStun = false;
    public float dotStunDuration = 0.2f;

    private void Update()
    {
        Vector2 center = (Vector2)transform.position + damageOffset;
        Collider2D[] hits = Physics2D.OverlapBoxAll(center, damageSize, 0f, targetLayer);

        foreach (Collider2D hit in hits)
        {
            PlayerHealth playerHealth = hit.GetComponent<PlayerHealth>();
            if (playerHealth != null)
            {
                if (instantDamage > 0)
                {
                    Vector2 appliedKnockback = applyKnockback ? knockbackForce : Vector2.zero;
                    playerHealth.TakeDamageHit(instantDamage, transform.position, appliedKnockback, knockbackStunDuration);
                }

                if (applyDOT)
                {
                    playerHealth.ApplyDOT(dotDamage, dotDuration, dotTickRate, dotCausesStun, dotStunDuration);
                }
            }
        }
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = new Color(1f, 0f, 0f, 0.4f);
        Gizmos.DrawCube((Vector2)transform.position + damageOffset, damageSize);
        Gizmos.DrawWireCube((Vector2)transform.position + damageOffset, damageSize);
    }
}