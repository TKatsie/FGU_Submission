using UnityEngine;

public class SceneTransitionManager : MonoBehaviour
{
    public static SceneTransitionManager Instance { get; private set; }

    // Stores the ID of the door the player should spawn at
    public string targetSpawnPointId;

    private void Awake()
    {
        // Simple Singleton pattern to keep this object alive across scenes
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }
}