using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelLoaderScript : MonoBehaviour
{
    public Animator transition;
    public float transitionTime = 1f;

    [Header("Target Scene")]
    [Tooltip("Insert the exact name of the scene to load")]
    public string TargetScene = "";

    [Header("Spawn Targeting")]
    [Tooltip("The ID of the spawn point the player should emerge from in the next scene.")]
    public string destinationSpawnId;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            // Pass the target spawn point ID to our manager before the scene changes
            if (SceneTransitionManager.Instance != null)
            {
                SceneTransitionManager.Instance.targetSpawnPointId = destinationSpawnId;
            }

            StartCoroutine(LoadLevelCoroutine());
        }
    }

    IEnumerator LoadLevelCoroutine()
    {
        // Trigger your fade-out animation
        if (transition != null)
        {
            transition.SetTrigger("Start");
        }

        // Wait for the transition to finish
        yield return new WaitForSeconds(transitionTime);

        // Load by scene name string
        SceneManager.LoadScene(TargetScene);
    }
}