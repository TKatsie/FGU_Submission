using UnityEngine;

public class PlayerSpawnPoint : MonoBehaviour
{
    [Tooltip("Match this unique ID string with the destinationSpawnId on the door leading here.")]
    public string spawnPointId;

    void Start()
    {
        if (SceneTransitionManager.Instance != null)
        {
            string targetId = SceneTransitionManager.Instance.targetSpawnPointId;

            // FIX: If targetId is blank or null, we didn't use a door! Do nothing.
            if (string.IsNullOrEmpty(targetId))
            {
                return;
            }

            // Only move the player if we came from a door and the ID matches
            if (spawnPointId == targetId)
            {
                GameObject player = GameObject.FindWithTag("Player");
                if (player != null)
                {
                    player.transform.position = transform.position;

                    // Optional: Reset the transition manager's target 
                    // so it doesn't accidentally trigger again later.
                    SceneTransitionManager.Instance.targetSpawnPointId = "";
                }
            }
        }
    }
}