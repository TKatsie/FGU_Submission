﻿using UnityEngine;
using UnityEngine.InputSystem;

// ─────────────────────────────────────────────────────────────────────────────
// PlayerCombat — handles all attack logic separately from movement.
// ─────────────────────────────────────────────────────────────────────────────

[RequireComponent(typeof(Animator))]
[RequireComponent(typeof(RetroPlayerController))]
public class PlayerCombat : MonoBehaviour
{
    [Header("Attack Settings")]
    public float jabDuration = 0.25f;
    public float crossDuration = 0.3f;
    public float comboBufferWindow = 0.15f;

    [Header("Hitbox — Jab (Attack 1)")]
    public Vector2 jabHitboxSize = new Vector2(0.8f, 0.6f);
    public float jabHitboxOffset = 0.5f;

    [Header("Hitbox — Cross (Attack 2)")]
    [Tooltip("Increase these values to give the combo finisher more forward reach and volume.")]
    public Vector2 crossHitboxSize = new Vector2(1.2f, 0.6f);
    public float crossHitboxOffset = 0.8f;

    [Header("Damage")]
    public int jabDamage = 5;
    public int crossDamage = 8;

    // ── Internals ─────────────────────────────────────────────────────────────
    private Animator animator;
    private RetroPlayerController movement;
    private Rigidbody2D rb;

    private InputAction attackAction;

    private bool isAttacking = false;
    private int comboStep = 0;
    private float attackTimer = 0f;
    private float currentDuration = 0f;
    private bool comboBuffered = false;
    private bool hitboxActive = false;

    private void Awake()
    {
        animator = GetComponent<Animator>();
        movement = GetComponent<RetroPlayerController>();
        rb = GetComponent<Rigidbody2D>();

        attackAction = new InputAction("Attack", binding: "<Mouse>/leftButton");
    }

    private void OnEnable() => attackAction.Enable();
    private void OnDisable() => attackAction.Disable();

    private void Update()
    {
        if (isAttacking)
        {
            attackTimer += Time.deltaTime;

            float timeLeft = currentDuration - attackTimer;

            // NEW: Only allow combo buffering if the player isn't suddenly stunned/busy
            if (timeLeft <= comboBufferWindow && movement.CanAttack)
            {
                if (attackAction.WasPressedThisFrame() || attackAction.IsPressed())
                {
                    comboBuffered = true;
                }
            }

            if (hitboxActive)
                PerformHitScan();

            if (attackTimer >= currentDuration)
            {
                isAttacking = false;
                hitboxActive = false;

                if (comboBuffered)
                {
                    comboBuffered = false;
                    StartNextAttack();
                }
                else
                {
                    comboStep = 0;
                    animator.SetBool("isAttacking", false);
                    animator.SetInteger("attackIndex", 0);
                    movement.SetCombatLock(false);
                }
            }
        }
        else
        {
            // NEW: Check `movement.CanAttack` before starting an attack from Idle/Running
            if (attackAction.WasPressedThisFrame() && movement.CanAttack)
            {
                comboStep = 0;
                StartNextAttack();
            }
        }
    }

    private void StartNextAttack()
    {
        comboStep = (comboStep % 2) + 1;

        isAttacking = true;
        attackTimer = 0f;
        comboBuffered = false;
        hitboxActive = false;
        currentDuration = (comboStep == 1) ? jabDuration : crossDuration;

        movement.SetCombatLock(true);

        animator.SetBool("isAttacking", true);
        animator.SetInteger("attackIndex", comboStep);
    }

    public void HitboxActive() => hitboxActive = true;
    public void HitboxInactive() => hitboxActive = false;

    // ── Damage Detection ──────────────────────────────────────────────────────
    private void PerformHitScan()
    {
        float facingDir = movement.LastFacingDirection;

        // DYNAMIC SELECTION: Picks the correct inspector values depending on the attack step
        Vector2 currentHitboxSize = (comboStep == 2) ? crossHitboxSize : jabHitboxSize;
        float currentHitboxOffset = (comboStep == 2) ? crossHitboxOffset : jabHitboxOffset;

        Vector2 hitCenter = (Vector2)transform.position
                           + new Vector2(facingDir * currentHitboxOffset, 0f);

        Collider2D[] hits = Physics2D.OverlapBoxAll(hitCenter, currentHitboxSize, 0f);

        foreach (Collider2D hit in hits)
        {
            if (hit.gameObject == gameObject) continue;

            IDamageable target = hit.GetComponent<IDamageable>();
            if (target == null) continue;

            int dmg = (comboStep == 1) ? jabDamage : crossDamage;
            target.TakeDamage(dmg);
        }

        hitboxActive = false;
    }

    // ── Gizmos (Dynamic Preview Matrix) ───────────────────────────────────────
    private void OnDrawGizmosSelected()
    {
        if (movement == null) return;

        // Use standard facing right direction if editor isn't in play-mode
        float facingDir = Application.isPlaying ? movement.LastFacingDirection : 1f;

        if (Application.isPlaying && isAttacking)
        {
            // RUNTIME VISUALIZATION: Highlights the exact active attack profile
            Vector2 activeSize = (comboStep == 2) ? crossHitboxSize : jabHitboxSize;
            float activeOffset = (comboStep == 2) ? crossHitboxOffset : jabHitboxOffset;
            Vector2 center = (Vector2)transform.position + new Vector2(facingDir * activeOffset, 0f);

            Gizmos.color = hitboxActive ? Color.red : new Color(1f, 0.4f, 0f);
            Gizmos.DrawWireCube(center, activeSize);
        }
        else
        {
            // DESIGN PREVIEW: Renders both bounds together so you can trace lengths perfectly
            // Green Box = Jab Profile
            Vector2 jabCenter = (Vector2)transform.position + new Vector2(facingDir * jabHitboxOffset, 0f);
            Gizmos.color = new Color(0.2f, 1f, 0.2f, 0.4f);
            Gizmos.DrawWireCube(jabCenter, jabHitboxSize);
            Gizmos.DrawCube(jabCenter, new Vector3(jabHitboxSize.x, jabHitboxSize.y, 0.01f));

            // Orange Box = Cross Profile
            Vector2 crossCenter = (Vector2)transform.position + new Vector2(facingDir * crossHitboxOffset, 0f);
            Gizmos.color = new Color(1f, 0.5f, 0f, 0.3f);
            Gizmos.DrawWireCube(crossCenter, crossHitboxSize);
            Gizmos.DrawCube(crossCenter, new Vector3(crossHitboxSize.x, crossHitboxSize.y, 0.01f));
        }
    }
}