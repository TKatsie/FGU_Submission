using UnityEngine;

public class CycleToggle : MonoBehaviour
{
    public float timeOn = 3f;
    public float timeOff = 3f;

    [Tooltip("Drag the DamageArea component here (can be on a child object)")]
    public DamageArea damageAreaToToggle;

    [Tooltip("Drag the ParticleSystem component here (can be on a child object)")]
    public ParticleSystem particlesToToggle;

    private float timer;
    private bool isOn = true;

    private void Awake()
    {
        timer = timeOn;
    }

    private void Update()
    {
        timer -= Time.deltaTime;
        if (timer <= 0f)
        {
            isOn = !isOn;
            timer = isOn ? timeOn : timeOff;

            if (damageAreaToToggle != null) damageAreaToToggle.enabled = isOn;

            if (particlesToToggle != null)
            {
                if (isOn) particlesToToggle.Play();
                else particlesToToggle.Stop();
            }
        }
    }
}