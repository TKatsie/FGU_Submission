using UnityEngine;

public class Void : MonoBehaviour
{
    [Header("Respawn Settings")]
    [Tooltip("Drag a GameObject/Transform here to act as the checkpoint checkpoint. If left empty, the player resets to where they started the level.")]
    public Transform respawnPoint;

    private Vector3 fallbackStartPos;

    private void Awake()
    {
        // Cache the player's initial position as a backup spawn point
        fallbackStartPos = transform.position;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        // Look for the player controller component on whatever touched this trigger
        RetroPlayerController player = collision.GetComponent<RetroPlayerController>();

        if (player != null)
        {
            // Determine spawn destination
            Vector3 targetSpawn = respawnPoint != null ? respawnPoint.position : fallbackStartPos;

            // Execute safe respawn
            player.Respawn(targetSpawn);
        }
    }
}