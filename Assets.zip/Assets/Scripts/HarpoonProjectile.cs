using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class HarpoonProjectile : MonoBehaviour
{
    [Header("Platform Trigger")]
    public GameObject climbableAnchorObject;

    [Header("Lifecycle Settings")]
    public float timeUntilFall = 5f;
    public float totalLifetime = 10f;

    private Rigidbody2D rb;
    private bool hasStuck = false;
    private bool hasFallen = false;
    private float ageTimer = 0f;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        if (climbableAnchorObject != null) climbableAnchorObject.SetActive(false);
    }

    private void Update()
    {
        if (!hasStuck && rb.linearVelocity.sqrMagnitude > 0.1f)
        {
            float angle = Mathf.Atan2(rb.linearVelocity.y, rb.linearVelocity.x) * Mathf.Rad2Deg;
            transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);

            if (rb.linearVelocity.x < 0f)
            {
                transform.localScale = new Vector3(1f, -1f, 1f);
            }
            else
            {
                transform.localScale = new Vector3(1f, 1f, 1f);
            }

            // Predictive Raycast to stop clipping/tunneling
            float checkDistance = rb.linearVelocity.magnitude * Time.deltaTime + 0.2f;
            Vector2 direction = rb.linearVelocity.normalized;

            RaycastHit2D hit = Physics2D.Raycast(transform.position, direction, checkDistance);

            if (hit.collider != null)
            {
                if (hit.collider.GetComponent<RetroPlayerController>() == null && !hit.collider.isTrigger)
                {
                    transform.position = hit.point;
                    Stick();
                }
            }
        }

        // --- CHEAT FIX: If speed drops to 0 but it hasn't registered a stick yet, FORCE IT ---
        if (!hasStuck && !hasFallen && rb.linearVelocity.sqrMagnitude <= 0.01f)
        {
            Stick();
        }
        // ----------------------------------------------------------------------------------

        ageTimer += Time.deltaTime;

        if (hasStuck && !hasFallen && ageTimer >= timeUntilFall)
        {
            hasFallen = true;
            rb.bodyType = RigidbodyType2D.Dynamic;
            if (climbableAnchorObject != null) climbableAnchorObject.SetActive(false);
        }

        if (ageTimer >= totalLifetime)
        {
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (hasStuck || hasFallen) return;
        if (collision.GetComponent<RetroPlayerController>() != null) return;
        if (collision.isTrigger) return;

        Stick();
    }

    private void Stick()
    {
        hasStuck = true;
        rb.bodyType = RigidbodyType2D.Static;
        rb.linearVelocity = Vector2.zero;

        int collisionLayer = LayerMask.NameToLayer("Collision");
        gameObject.layer = collisionLayer;

        // --- CHEAT FIX: Completely stripped out angle requirements. If it stops, it clones! ---
        if (climbableAnchorObject != null)
        {
            climbableAnchorObject.SetActive(true);
            climbableAnchorObject.layer = collisionLayer;

            climbableAnchorObject.transform.SetParent(null);
            climbableAnchorObject.transform.rotation = Quaternion.identity;
            climbableAnchorObject.transform.localScale = Vector3.one;
        }
    }

    private void OnDestroy()
    {
        if (climbableAnchorObject != null)
        {
            Destroy(climbableAnchorObject);
        }
    }
}