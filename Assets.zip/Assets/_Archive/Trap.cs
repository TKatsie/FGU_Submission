using UnityEngine;

public class Trap : MonoBehaviour
{
    private enum TrapState { Idle, WarmingUp, Firing, Cooldown, Disabled }
    private TrapState currentState = TrapState.Idle;

    [Header("Hitboxes (Use Scene View Gizmos to align)")]
    public Vector2 activationSize = new Vector2(2f, 2f);
    public Vector2 activationOffset = Vector2.zero;
    public Vector2 damageSize = new Vector2(1.5f, 1.5f);
    public Vector2 damageOffset = Vector2.zero;
    public LayerMask targetLayer; // Set this to your Player layer!

    [Header("Activation & Lifecycle")]
    [Tooltip("If false, the trap fires instantly when touched.")]
    public bool useActivationDelay = false;
    public float activationDelay = 3f;

    [Header("Always Active (e.g. Static Fog/Spikes)")]
    [Tooltip("If true, skips activation and cooldowns. Always applies damage/DOT to anyone in the Damage Hitbox.")]
    public bool isAlwaysActive = false;

    [Header("Visual Effects")]
    [Tooltip("Spawned once when the trap fires (e.g., an Explosion animation prefab).")]
    public GameObject firingVFXPrefab;
    [Tooltip("How long before the explosion prefab is destroyed from the scene.")]
    public float firingVFXDuration = 1f;

    [Tooltip("Continuous effects (e.g., Smoke/Poison). Drag a child ParticleSystem here.")]
    public ParticleSystem continuousVFX;

    [Tooltip("Does the trap reset after firing, or is it one-time use?")]
    public bool isRepeatable = true;
    public float resetCooldown = 2f;

    [Tooltip("If true, the trap deletes itself after it finishes firing/cooling down.")]
    public bool destroyAfterFiring = false;
    public float destroyDelay = 0.5f;

    [Header("Main Damage (Instant)")]
    public int instantDamage = 15;
    public bool applyKnockback = true;
    public Vector2 knockbackForce = new Vector2(10f, 12f);
    public float knockbackStunDuration = 0.35f;

    [Header("Damage Over Time (DOT)")]
    public bool applyDOT = false;
    public int dotDamage = 2;
    public float dotDuration = 10f;
    public float dotTickRate = 2f;

    [Tooltip("Should the DOT tick act like an electric shock?")]
    public bool dotCausesStun = false;
    public float dotStunDuration = 0.2f;

    private float timer = 0f;

    private void Start()
    {
        // If it's a permanent trap like fog, start the smoke immediately and leave it on!
        if (isAlwaysActive && continuousVFX != null)
        {
            continuousVFX.Play();
        }
    }

    private void Update()
    {
        // NEW: If it's a static trap, just constantly check for targets and apply damage.
        // Your PlayerHealth.cs i-frames will prevent it from dealing damage every frame.
        if (isAlwaysActive)
        {
            ApplyDamageToTargets();
            return; // Skip the rest of the state machine!
        }

        switch (currentState)
        {
            case TrapState.Idle:
                if (CheckHitbox(activationSize, activationOffset))
                {
                    if (useActivationDelay)
                    {
                        currentState = TrapState.WarmingUp;
                        timer = activationDelay;
                    }
                    else
                    {
                        FireTrap();
                    }
                }
                break;

            case TrapState.WarmingUp:
                timer -= Time.deltaTime;
                if (timer <= 0f)
                {
                    FireTrap();
                }
                break;

            case TrapState.Firing:
                ApplyDamageToTargets();

                if (isRepeatable)
                {
                    currentState = TrapState.Cooldown;
                    timer = resetCooldown;

                    // Stop the smoke while cooling down (Only applies to non-Always Active traps)
                    if (continuousVFX != null) continuousVFX.Stop();
                }
                else
                {
                    currentState = TrapState.Disabled;
                    if (destroyAfterFiring) Destroy(gameObject, destroyDelay);
                }
                break;

            case TrapState.Cooldown:
                timer -= Time.deltaTime;
                if (timer <= 0f)
                {
                    currentState = TrapState.Idle;
                }
                break;
        }
    }

    private void FireTrap()
    {
        currentState = TrapState.Firing;

        // 1. Spawn the one-shot explosion!
        if (firingVFXPrefab != null)
        {
            // Instantiates the explosion, and tells Unity to destroy it after 'firingVFXDuration' seconds
            GameObject explosion = Instantiate(firingVFXPrefab, transform.position + (Vector3)damageOffset, Quaternion.identity);
            Destroy(explosion, firingVFXDuration);
        }

        // 2. Turn on the continuous smoke/poison!
        if (continuousVFX != null)
        {
            continuousVFX.Play();
        }
    }

    private bool CheckHitbox(Vector2 size, Vector2 offset)
    {
        Vector2 center = (Vector2)transform.position + offset;
        return Physics2D.OverlapBox(center, size, 0f, targetLayer) != null;
    }

    private void ApplyDamageToTargets()
    {
        Vector2 center = (Vector2)transform.position + damageOffset;
        Collider2D[] hits = Physics2D.OverlapBoxAll(center, damageSize, 0f, targetLayer);

        foreach (Collider2D hit in hits)
        {
            PlayerHealth playerHealth = hit.GetComponent<PlayerHealth>();
            if (playerHealth != null)
            {
                // 1. Apply Main Damage (Obeys i-frames inside PlayerHealth)
                if (instantDamage > 0)
                {
                    Vector2 appliedKnockback = applyKnockback ? knockbackForce : Vector2.zero;
                    playerHealth.TakeDamageHit(instantDamage, transform.position, appliedKnockback, knockbackStunDuration);
                }

                // 2. Apply DOT (Refreshes the duration, ignores i-frames)
                if (applyDOT)
                {
                    playerHealth.ApplyDOT(dotDamage, dotDuration, dotTickRate, dotCausesStun, dotStunDuration);
                }
            }
        }
    }

    // This draws the hitboxes in the Unity Editor just like your PlayerCombat script does[cite: 1]
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = new Color(0f, 1f, 1f, 0.3f); // Cyan for Activation
        Gizmos.DrawCube((Vector2)transform.position + activationOffset, activationSize);
        Gizmos.DrawWireCube((Vector2)transform.position + activationOffset, activationSize);

        Gizmos.color = new Color(1f, 0f, 0f, 0.4f); // Red for Damage
        Gizmos.DrawCube((Vector2)transform.position + damageOffset, damageSize);
        Gizmos.DrawWireCube((Vector2)transform.position + damageOffset, damageSize);
    }
}